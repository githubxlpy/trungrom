<?php return array (
  'domain' => 'notifications',
  'plural-forms' => 'nplurals=1; plural=0;',
  'messages' => 
  array (
    '' => 
    array (
      'Notifications are cleared!' => 'Pemberitahuan dihapus!',
      'Users on registration' => 'Pengguna pada saat pendaftaran',
      'Articles on moderation' => 'Artikel tentang moderasi',
      'Downloads on moderation' => 'Popularitas di moderasi',
      'Ban' => 'Blokir',
      'New forum posts' => 'Baru posting forum',
      'Mail' => 'Pesan',
      'Guestbook' => 'Buku Tamu',
      'Comments' => 'Komentar',
      'Settings' => 'Pengaturan',
      'Settings saved!' => 'Pengaturan disimpan!',
      'Notifications' => 'Pemberitahuan',
      'All notifications have already been read' => 'Semua pemberitahuan telah membaca',
      'Total' => 'Total',
      'Clear notifications' => 'Menghapus pemberitahuan',
      'Display the number of unread messages in the forum' => 'Menampilkan jumlah pesan yang belum dibaca di forum',
      'Save' => 'Simpan',
      'Cancel' => 'Batal',
    ),
  ),
);