<?php return array (
  'domain' => 'notifications',
  'plural-forms' => 'nplurals=3; plural=(n==1 ? 0 : (n==0 || (n%100>0 && n%100<20)) ? 1 : 2);',
  'messages' => 
  array (
    '' => 
    array (
      'Notifications are cleared!' => 'Notificările sunt șterse!',
      'Users on registration' => 'Utilizatori la înregistrare',
      'Articles on moderation' => 'Fisiere cu moderare',
      'Downloads on moderation' => 'Descărcări la moderare',
      'Ban' => 'Ban',
      'New forum posts' => 'Postări noi pe forum',
      'Mail' => 'Mail',
      'Guestbook' => 'Guestbook',
      'Comments' => 'Comentarii',
      'Settings' => 'Setari',
      'Settings saved!' => 'Setări salvate!',
      'Notifications' => 'Notificări',
      'All notifications have already been read' => 'Toate notificările au fost deja citite',
      'Total' => 'Toatal',
      'Clear notifications' => 'Ștergeți notificările',
      'Display the number of unread messages in the forum' => 'Afișează numărul de mesaje necitite în forum',
      'Save' => 'Salveaza',
      'Cancel' => 'Anuleaza',
    ),
  ),
);