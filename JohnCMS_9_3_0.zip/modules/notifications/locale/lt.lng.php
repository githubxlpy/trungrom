<?php return array (
  'domain' => 'notifications',
  'plural-forms' => 'nplurals=4; plural=(n%10==1 && (n%100>19 || n%100<11) ? 0 : (n%10>=2 && n%10<=9) && (n%100>19 || n%100<11) ? 1 : n%1!=0 ? 2: 3);',
  'messages' => 
  array (
    '' => 
    array (
      'Notifications are cleared!' => 'Pranešimai išvalytas!',
      'Users on registration' => 'Vartotojų registracija',
      'Articles on moderation' => 'Failas ant moderacijos',
      'Downloads on moderation' => 'Siuntiniai laukia moderacijos',
      'Ban' => 'Bluokas',
      'New forum posts' => 'Nauji pranešimai forume',
      'Mail' => 'Paštas',
      'Guestbook' => 'Svečių Knyga',
      'Comments' => 'Komentarai',
      'Settings' => 'Nustatymai',
      'Settings saved!' => 'Nustatymai išsaugoti!',
      'Notifications' => 'Pranešimai',
      'All notifications have already been read' => 'Visi pranešimai perskaityti',
      'Total' => 'Viso',
      'Clear notifications' => 'Aišku pranešimų',
      'Display the number of unread messages in the forum' => 'Rodyti neskaitytų žinučių skaičių forume',
      'Save' => 'Išsaugoti',
      'Cancel' => 'Atšaukti',
    ),
  ),
);