<?php return array (
  'domain' => 'notifications',
  'plural-forms' => 'nplurals=2; plural=(n != 1);',
  'messages' => 
  array (
    '' => 
    array (
      'Notifications are cleared!' => 'Эскертмелер тазаланды!',
      'Users on registration' => 'Катталган колдонуучулар',
      'Articles on moderation' => 'Макалалар текшерилүүдө',
      'Downloads on moderation' => 'Жүктөө текшерилүүдө',
      'Ban' => 'Тыюу салуу',
      'New forum posts' => 'Форумда жаңы билдирүүлөр',
      'Mail' => 'Электрондук дарек',
      'Guestbook' => 'Конок китеби',
      'Comments' => 'Билдирүүлөр',
      'Settings' => 'Орнотуулар',
      'Settings saved!' => 'Орнотуулар сакталды!',
      'Notifications' => 'Эскертме',
      'All notifications have already been read' => 'Бардык эскертмелер буга чейин окулган',
      'Total' => 'Баары',
      'Clear notifications' => 'Эскертмелерди тазалоо',
      'Display the number of unread messages in the forum' => 'Форумда окула элек билдирүүлөрдүн санын көрсөтүү',
      'Save' => 'Сактоо',
      'Cancel' => 'Токтотуу',
    ),
  ),
);