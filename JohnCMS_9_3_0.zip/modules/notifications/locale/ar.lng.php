<?php return array (
  'domain' => 'notifications',
  'plural-forms' => 'nplurals=6; plural=(n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5);',
  'messages' => 
  array (
    '' => 
    array (
      'Notifications are cleared!' => 'تم مسح الإخطارات!',
      'Users on registration' => 'المستخدمون عند التسجيل',
      'Articles on moderation' => 'مقالات عن الاعتدال',
      'Downloads on moderation' => 'التنزيلات على الاعتدال',
      'Ban' => 'الحظر',
      'New forum posts' => 'مشاركات منتدى جديدة',
      'Mail' => 'البريـــد',
      'Guestbook' => 'سجل الزوار',
      'Comments' => 'التعليقات',
      'Settings' => 'الإعدادات',
      'Settings saved!' => 'تم حفظ الإعدادات!',
      'Notifications' => 'تنبيهات',
      'All notifications have already been read' => 'تمت قراءة جميع الإخطارات بالفعل',
      'Total' => 'مجموع',
      'Clear notifications' => 'مسح الإشعارات',
      'Display the number of unread messages in the forum' => 'عرض عدد الرسائل غير المقروءة في المنتدى',
      'Save' => 'حفظ',
      'Cancel' => 'إلغاء الأمر',
    ),
  ),
);