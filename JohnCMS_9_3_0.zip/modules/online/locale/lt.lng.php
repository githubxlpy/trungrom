<?php return array (
  'domain' => 'online',
  'plural-forms' => 'nplurals=4; plural=(n%10==1 && (n%100>19 || n%100<11) ? 0 : (n%10>=2 && n%10<=9) && (n%100>19 || n%100<11) ? 1 : n%1!=0 ? 2: 3);',
  'messages' => 
  array (
    '' => 
    array (
      'Users' => 'Vartotojai',
      'History' => 'Istorija',
      'Guests' => 'Svečiai',
      'IP Activity' => 'IP Aktyvumas',
      'Guest' => 'Svečias',
      'Who is online?' => 'Kas Prisijungę?',
      'Online' => 'Prisijungę',
      'For registered users only' => 'Tik registruotiems Vartotojams',
      'List is empty' => 'Sąrašas tuščias',
      'Total' => 'Viso',
    ),
  ),
);