<?php return array (
  'domain' => 'online',
  'plural-forms' => 'nplurals=2; plural=(n > 1);',
  'messages' => 
  array (
    '' => 
    array (
      'Users' => 'Foydalanuvchilar',
      'History' => 'Tarix',
      'Guests' => 'Mehmonlar',
      'IP Activity' => 'IP Faollik',
      'Guest' => 'Mehmon',
      'Who is online?' => 'Kim online?',
      'Online' => 'Onlayn',
      'For registered users only' => 'Faqat ro\'yxatdan o\'tgan foydalanuvchilar uchun',
      'List is empty' => 'Ro\'yhat bo\'sh',
      'Total' => 'Jami',
    ),
  ),
);