<?php return array (
  'domain' => 'online',
  'plural-forms' => 'nplurals=3; plural=(n==1 ? 0 : (n==0 || (n%100>0 && n%100<20)) ? 1 : 2);',
  'messages' => 
  array (
    '' => 
    array (
      'Users' => 'Utilizatori',
      'History' => 'Istoric',
      'Guests' => 'Oaspeti',
      'IP Activity' => 'Activitate IP',
      'Guest' => 'Oaspete',
      'Who is online?' => 'Cine este online?',
      'Online' => 'Online',
      'For registered users only' => 'Doar pentru utilizatori inregistrati',
      'List is empty' => 'Lista este goală',
      'Total' => 'Toatal',
    ),
  ),
);